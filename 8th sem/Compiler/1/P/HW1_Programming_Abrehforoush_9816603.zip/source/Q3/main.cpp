#include<stdio.h>
int main(){
	int i = 1;
	double b,c;
	double d[4];
}

