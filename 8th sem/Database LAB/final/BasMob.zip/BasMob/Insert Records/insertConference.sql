insert into Conference values('West')
insert into Conference values('East')