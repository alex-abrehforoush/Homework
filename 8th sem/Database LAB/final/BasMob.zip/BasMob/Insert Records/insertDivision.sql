insert into Division values ('Atlantic')
insert into Division values ('Central')
insert into Division values ('SouthEast')
insert into Division values ('NorthWest')
insert into Division values ('Pacific')
insert into Division values ('SouthWest')


