INSERT INTO Game (HostTeamID, GuestTeamID, HostTeamScore, GuestTeamScore, WinnerTeam)
VALUES (4, 5, 104, 99, 4),
       (7, 1, 74, 88, 1),
       (1, 3, 32, 45, 3),
       (4, 8, 131, 145, 8),
       (6, 2, 102, 110, 2),
       (9, 4, 90, 105, 4);
