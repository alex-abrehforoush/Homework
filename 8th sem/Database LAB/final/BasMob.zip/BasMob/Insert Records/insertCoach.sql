-- Inserting sample data into the Coach table
INSERT INTO Coach
VALUES
    ('John Doe', '1980-05-10', 10),
    ('Jane Smith', '1975-12-15', 15),
    ('Michael Johnson', '1992-08-25', 5),
    ('Sarah Thompson', '1988-03-07', 8),
    ('David Wilson', '1983-09-22', 12),
    ('Emily Davis', '1995-06-18', 3),
    ('Robert Lee', '1972-11-30', 20),
    ('Olivia Brown', '1990-04-12', 7),
    ('William Turner', '1986-07-03', 9),
    ('Sophia Hernandez', '1991-02-08', 6),
    ('Daniel Adams', '1987-10-14', 11),
    ('Isabella White', '1994-03-26', 4),
    ('Andrew Taylor', '1984-09-17', 13),
    ('Ava Lewis', '1993-07-21', 2),
    ('Matthew Clark', '1979-06-04', 17);
