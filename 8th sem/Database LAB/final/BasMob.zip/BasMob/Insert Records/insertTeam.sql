-- Inserting sample data into the Team table
INSERT INTO Team
VALUES
    ('Los Angeles Lakers', 'Staples Center', 'Los Angeles', 1, 1, 1),
    ('Boston Celtics', 'TD Garden', 'Boston', 1, 1, 2),
    ('Golden State Warriors', 'Chase Center', 'San Francisco', 2, 1, 3),
    ('Miami Heat', 'American Airlines Arena', 'Miami', 2, 2, 4),
    ('Houston Rockets', 'Toyota Center', 'Houston', 1, 2, 5),
    ('Chicago Bulls', 'United Center', 'Chicago', 2, 2, 6),
    ('San Antonio Spurs', 'AT&T Center', 'San Antonio', 1, 1, 7),
    ('Toronto Raptors', 'Scotiabank Arena', 'Toronto', 2, 1, 8),
    ('Brooklyn Nets', 'Barclays Center', 'Brooklyn', 1, 2, 9),
    ('Philadelphia 76ers', 'Wells Fargo Center', 'Philadelphia', 2, 2, 10),
    ('Dallas Mavericks', 'American Airlines Center', 'Dallas', 1, 1, 11),
    ('Denver Nuggets', 'Ball Arena', 'Denver', 2, 1, 12);
