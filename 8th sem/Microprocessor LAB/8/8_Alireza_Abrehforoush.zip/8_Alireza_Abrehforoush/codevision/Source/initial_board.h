#ifndef _initial_board_INCLUDED_
#define _initial_board_INCLUDED_

void initialBoard();

#endif