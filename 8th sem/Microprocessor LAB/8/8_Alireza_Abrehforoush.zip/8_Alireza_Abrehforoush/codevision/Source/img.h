/****************************************************************************
Image data created by the LCD Vision V font & image editor/converter
(C) Copyright 2011-2020 Pavel Haiduc, HP InfoTech S.R.L.
http://www.hpinfotech.ro

Graphic LCD controller: KS0108 128x64 CS1,CS2
Imported image file name: Yin_and_Yang.png
Imported image width: 131 pixels
Imported image height: 64 pixels
Exported image width: 128 pixels
Exported image height: 64 pixels

Color depth: 1 bits/pixel
Exported monochrome image data size:
1028 bytes for displays organized as horizontal rows of bytes
1028 bytes for displays org
****************************************************************************/

#ifndef _IMG_INCLUDED_
#define _IMG_INCLUDED_

extern flash unsigned char Yin_and_Yang[];

#endif

