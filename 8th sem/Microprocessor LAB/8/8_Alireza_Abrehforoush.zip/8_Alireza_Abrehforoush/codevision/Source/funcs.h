#ifndef _funcs_INCLUDED_
#define _funcs_INCLUDED_


void func1();
void func2();
void func3();


#endif