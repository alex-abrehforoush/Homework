#ifndef _functions_INCLUDED_
#define _functions_INCLUDED_

void set_baudrate(int br);
void question3();
void question4();

#endif