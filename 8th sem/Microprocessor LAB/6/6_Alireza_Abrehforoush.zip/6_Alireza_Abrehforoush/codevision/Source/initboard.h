#ifndef _initboard_INCLUDED_
#define _initboard_INCLUDED_

void initBoard();

#endif
