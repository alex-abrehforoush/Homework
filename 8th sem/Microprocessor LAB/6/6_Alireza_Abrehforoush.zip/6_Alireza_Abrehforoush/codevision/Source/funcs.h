#ifndef _funcs_INCLUDED_
#define _funcs_INCLUDED_

void func1(unsigned char input_index);
void func2(unsigned char input_index);
void func3();

#endif

