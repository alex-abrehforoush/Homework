#ifndef _functions_INCLUDED_
#define _functions_INCLUDED_

void displayTime(char  hour, char minute, char second, char msec);
void displayCapacity(int capacity);
void initDisplay();
void stopwatch();
void parking();
void displayPeriod();

#endif
