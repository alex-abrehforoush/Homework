#ifndef _SecondLab_INCLUDED_
#define _SecondLab_INCLUDED_

char part1(char port_in);
void part2(char data_in, char port_out);
void part3(int number, unsigned int interval);
void part4();
void part5(int data, char data_port, char enable_data);

#endif
