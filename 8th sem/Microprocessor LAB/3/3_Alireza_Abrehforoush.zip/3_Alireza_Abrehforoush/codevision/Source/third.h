#ifndef _third_INCLUDED_
#define _third_INCLUDED_

void part1();
void part2();
void part3();
void part4();
void part5();

#endif