#ifndef _initialization_INCLUDED_
#define _initialization_INCLUDED_

void initialize();

#endif
