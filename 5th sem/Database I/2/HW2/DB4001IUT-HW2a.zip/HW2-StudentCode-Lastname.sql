---- DATABASE DESIGN 1 @ IUT
---- YOUR NAME:
---- YOUR STUDENT NUMBER: 


---- Q4-A



---- Q4-B



---- Q4-C



---- Q4-D



---- Q4-E



---- Q4-F



---- Q5-A



---- Q5-B



---- Q5-C



---- Q5-D



---- Q5-E



---- Q5-F

	
	
---- Q5-G



---- Q5-H



