---- DATABASE DESIGN 1 @ IUT
---- YOUR NAME:
---- YOUR STUDENT NUMBER: 


---- Q1
---A

---B



---- Q2
---A


---B


---C


---D




---- Q4
---A


---B


---C





---- Q5
---A


---B


---C


---D



---- Q6



---- Q7

	
	
---- Q8







