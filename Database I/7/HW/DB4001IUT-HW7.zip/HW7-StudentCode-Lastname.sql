---- DATABASE DESIGN 1 @ IUT
---- YOUR NAME:
---- YOUR STUDENT NUMBER: 


---- Q1
---A

---B

---C



---- Q2
---A


---B



---- Q3


---- Q4



---- Q5
---A


---B










