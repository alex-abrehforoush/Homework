---- DATABASE DESIGN 1 @ IUT Homework6
---- YOUR NAME:
---- YOUR STUDENT NUMBER: 


---- Q1



---- Q2




---- Q3




---- Q5



---- Q6



---- Q7
---A


---B


---C



---D	
	
---- Q8

---A


---B


---C


---Q9


---Q10


